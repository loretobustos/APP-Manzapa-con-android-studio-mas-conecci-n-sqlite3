package com.example.appmanzanacanela_loretobustos

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MenuPrincipalActivity : AppCompatActivity() {

    lateinit var btnCafe: Button
    lateinit var btnMate: Button
    lateinit var btnTe: Button
    lateinit var btnPedido: Button
    lateinit var btnCerrarSesion: Button
    lateinit var tvUsuarioActivo: TextView

    var usuarioActual = "admin"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_menu_principal)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 1. Enlace exacto de vistas con el XML
        btnCafe = findViewById(R.id.btnCatCafe)
        btnMate = findViewById(R.id.btnCatMate)
        btnTe = findViewById(R.id.btnCatTe)
        btnPedido = findViewById(R.id.btnIrDirectoPedido)
        btnCerrarSesion = findViewById(R.id.btnCerrarSesion)
        tvUsuarioActivo = findViewById(R.id.tvUsuarioActivo)

        // 2. Recibir el usuario activo desde el Login o Registro
        val bundle = intent.extras
        if (bundle != null && bundle.containsKey("nombreUsuario")) {
            usuarioActual = bundle.getString("nombreUsuario") ?: "admin"
        }
        tvUsuarioActivo.text = "Sesión Activa: $usuarioActual"

        // 3. Navegación a Cafetería
        btnCafe.setOnClickListener {
            val intent = Intent(this, CafeActivity::class.java).apply {
                putExtra("nombreUsuario", usuarioActual)
            }
            startActivity(intent)
        }

        // 4. Navegación a Matería
        btnMate.setOnClickListener {
            val intent = Intent(this, MateActivity::class.java).apply {
                putExtra("nombreUsuario", usuarioActual)
            }
            startActivity(intent)
        }

        // 5. Navegación a Tetería
        btnTe.setOnClickListener {
            val intent = Intent(this, TeActivity::class.java).apply {
                putExtra("nombreUsuario", usuarioActual)
            }
            startActivity(intent)
        }

        // 6. Acceso directo al Carrito / Pedido
        btnPedido.setOnClickListener {
            val intent = Intent(this, MiPedidoActivity::class.java).apply {
                putExtra("nombreUsuario", usuarioActual)
            }
            startActivity(intent)
        }

        // 7. BOTÓN CERRAR SESIÓN: Limpia la pila y regresa al MainActivity
        btnCerrarSesion.setOnClickListener {
            Toast.makeText(this, "Sesión cerrada correctamente", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            startActivity(intent)
            finish()
        }
    }
}