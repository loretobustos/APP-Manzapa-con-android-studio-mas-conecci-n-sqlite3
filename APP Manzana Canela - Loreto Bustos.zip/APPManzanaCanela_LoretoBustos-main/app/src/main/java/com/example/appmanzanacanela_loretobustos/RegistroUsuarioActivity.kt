package com.example.appmanzanacanela_loretobustos

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class RegistroUsuarioActivity : AppCompatActivity() {

    lateinit var etNombre: EditText
    lateinit var etEmail: EditText
    lateinit var etTelefono: EditText
    lateinit var etDireccion: EditText
    lateinit var etClave: EditText
    lateinit var etConfirmarClave: EditText
    lateinit var btnCrearCuenta: Button
    lateinit var btnIrLogin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_registro_usuario)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 1. Enlace de los componentes del XML con findViewById
        etNombre = findViewById(R.id.etNombreRegistro)
        etEmail = findViewById(R.id.etEmailRegistro)
        etTelefono = findViewById(R.id.etTelefonoRegistro)
        etDireccion = findViewById(R.id.etDireccionRegistro)
        etClave = findViewById(R.id.etClaveRegistro)
        etConfirmarClave = findViewById(R.id.etConfirmarClaveRegistro)
        btnCrearCuenta = findViewById(R.id.btnCrearCuenta)
        btnIrLogin = findViewById(R.id.btnIrLoginDesdeReg)

        // 2. Evento Crear Cuenta: Validaciones y registro persistente en SQLite3
        btnCrearCuenta.setOnClickListener {
            val nombre = etNombre.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val telefono = etTelefono.text.toString().trim()
            val direccion = etDireccion.text.toString().trim()
            val clave = etClave.text.toString().trim()
            val confirmarClave = etConfirmarClave.text.toString().trim()

            if (nombre.isEmpty() || email.isEmpty() || telefono.isEmpty() || direccion.isEmpty() || clave.isEmpty() || confirmarClave.isEmpty()) {
                Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show()
            } else if (clave.length != 6) {
                Toast.makeText(this, "La clave debe tener 6 dígitos numéricos", Toast.LENGTH_SHORT).show()
            } else if (clave != confirmarClave) {
                Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show()
            } else {
                // Conexión a la base de datos SQLite3 con el nombre unificado "administracion"
                val admin = AdminSQLiteOpenHelper(this, "administracion", null, 1)
                val db = admin.writableDatabase

                // Verificar si el usuario ya existe en la tabla usuarios
                val cursor = db.rawQuery(
                    "SELECT id_usuario FROM usuarios WHERE nombre_usuario = ?",
                    arrayOf(nombre)
                )

                if (cursor.moveToFirst()) {
                    Toast.makeText(this, "Ese nombre de usuario ya está registrado", Toast.LENGTH_SHORT).show()
                    cursor.close()
                    db.close()
                } else {
                    cursor.close()

                    // Insertar el nuevo usuario en la tabla usuarios
                    val registro = ContentValues().apply {
                        put("nombre_usuario", nombre)
                        put("contrasena", clave)
                    }

                    val resultado = db.insert("usuarios", null, registro)
                    db.close()

                    if (resultado != -1L) {
                        Toast.makeText(this, "Usuario guardado en SQLite. ¡Bienvenida/o, $nombre!", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this, MenuPrincipalActivity::class.java).apply {
                            putExtra("nombreUsuario", nombre)
                            putExtra("emailUsuario", email)
                            putExtra("direccionUsuario", direccion)
                        }
                        startActivity(intent)
                        finish()
                    } else {
                        Toast.makeText(this, "Error al guardar el usuario en la base de datos", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        // 3. Botón Ya tengo cuenta: Deriva a Inicio de Sesión
        btnIrLogin.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}