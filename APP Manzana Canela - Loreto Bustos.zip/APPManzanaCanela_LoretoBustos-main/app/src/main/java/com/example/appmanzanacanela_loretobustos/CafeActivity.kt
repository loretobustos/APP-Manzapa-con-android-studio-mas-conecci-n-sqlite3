package com.example.appmanzanacanela_loretobustos

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class CafeActivity : AppCompatActivity() {

    // 1. Declaración de variables para los componentes de la interfaz
    lateinit var btnEspresso: Button
    lateinit var btnCappuccino: Button
    lateinit var btnLatte: Button
    lateinit var btnIrPedido: Button
    lateinit var btnVolver: Button

    lateinit var etCantEspresso: EditText
    lateinit var etCantCappuccino: EditText
    lateinit var etCantLatte: EditText

    // TextViews para mostrar dinámicamente los precios desde SQLite
    lateinit var tvPrecioEspresso: TextView
    lateinit var tvPrecioCappuccino: TextView
    lateinit var tvPrecioLatte: TextView

    // Variables numéricas para almacenar los precios recuperados de la BD
    var precioEspresso = 0
    var precioCappuccino = 0
    var precioLatte = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_cafe)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 2. Enlace de vistas con el XML usando los IDs exactos
        btnEspresso = findViewById(R.id.btnPedirEspresso)
        btnCappuccino = findViewById(R.id.btnPedirCappuccino)
        btnLatte = findViewById(R.id.btnPedirLatte)
        btnIrPedido = findViewById(R.id.btnIrPedidoCafe)
        btnVolver = findViewById(R.id.btnVolverMenuDesdeCafe)

        etCantEspresso = findViewById(R.id.etCantEspresso)
        etCantCappuccino = findViewById(R.id.etCantCappuccino)
        etCantLatte = findViewById(R.id.etCantLatte)

        tvPrecioEspresso = findViewById(R.id.tvPrecioEspresso)
        tvPrecioCappuccino = findViewById(R.id.tvPrecioCappuccino)
        tvPrecioLatte = findViewById(R.id.tvPrecioLatte)

        // 3. Cargar precios reales desde SQLite3 (Criterio 3 de la pauta)
        cargarPreciosDesdeBD()

        // 4. Eventos al presionar Pedir en cada variedad de café
        btnEspresso.setOnClickListener {
            procesarPedido("Café Espresso", etCantEspresso.text.toString(), precioEspresso)
        }

        btnCappuccino.setOnClickListener {
            procesarPedido("Cappuccino Canela", etCantCappuccino.text.toString(), precioCappuccino)
        }

        btnLatte.setOnClickListener {
            procesarPedido("Latte Manzana", etCantLatte.text.toString(), precioLatte)
        }

        // 5. Ir directo al carrito / resumen de pedido
        btnIrPedido.setOnClickListener {
            val intent = Intent(this, MiPedidoActivity::class.java)
            startActivity(intent)
        }

        // 6. Volver al menú principal
        btnVolver.setOnClickListener {
            finish()
        }
    }

    // Método para realizar la consulta SQL y obtener los precios reales
    private fun cargarPreciosDesdeBD() {
        val admin = AdminSQLiteOpenHelper(this, "administracion", null, 1)
        val bd: SQLiteDatabase = admin.readableDatabase

        // Consulta para Café Espresso
        val filaEspresso = bd.rawQuery("SELECT precio FROM productos WHERE nombre='Café Espresso'", null)
        if (filaEspresso.moveToFirst()) {
            precioEspresso = filaEspresso.getInt(0)
            tvPrecioEspresso.text = "$$precioEspresso"
        } else {
            tvPrecioEspresso.text = "No disponible"
        }
        filaEspresso.close()

        // Consulta para Cappuccino Canela
        val filaCappuccino = bd.rawQuery("SELECT precio FROM productos WHERE nombre='Cappuccino Canela'", null)
        if (filaCappuccino.moveToFirst()) {
            precioCappuccino = filaCappuccino.getInt(0)
            tvPrecioCappuccino.text = "$$precioCappuccino"
        } else {
            tvPrecioCappuccino.text = "No disponible"
        }
        filaCappuccino.close()

        // Consulta para Latte Manzana
        val filaLatte = bd.rawQuery("SELECT precio FROM productos WHERE nombre='Latte Manzana'", null)
        if (filaLatte.moveToFirst()) {
            precioLatte = filaLatte.getInt(0)
            tvPrecioLatte.text = "$$precioLatte"
        } else {
            tvPrecioLatte.text = "No disponible"
        }
        filaLatte.close()

        bd.close()
    }

    // 7. Procesamiento numérico, validación de cantidad y paso de parámetros por Intent
    private fun procesarPedido(producto: String, textoCantidad: String, precioUnitario: Int) {
        val cantidad = textoCantidad.toIntOrNull() ?: 1 // Por defecto 1 si está vacío

        if (cantidad <= 0) {
            Toast.makeText(this, "Ingrese una cantidad válida mayor a 0", Toast.LENGTH_SHORT).show()
        } else if (precioUnitario == 0) {
            Toast.makeText(this, "Error: No se pudo cargar el precio del producto", Toast.LENGTH_SHORT).show()
        } else {
            val subtotal = precioUnitario * cantidad

            val intent = Intent(this, MiPedidoActivity::class.java)
            intent.putExtra("producto", producto)
            intent.putExtra("cantidad", cantidad.toString())
            intent.putExtra("precioUnitario", precioUnitario.toString())
            intent.putExtra("subtotal", subtotal.toString())
            startActivity(intent)

            Toast.makeText(this, "$producto agregado al pedido", Toast.LENGTH_SHORT).show()
        }
    }
}