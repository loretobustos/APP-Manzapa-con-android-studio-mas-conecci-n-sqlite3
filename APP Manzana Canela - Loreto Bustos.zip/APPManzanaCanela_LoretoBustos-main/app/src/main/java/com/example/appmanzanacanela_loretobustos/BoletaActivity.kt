package com.example.appmanzanacanela_loretobustos

import android.content.ContentValues
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BoletaActivity : AppCompatActivity() {

    // Vistas de la boleta
    lateinit var tvNumPedido: TextView
    lateinit var tvDatosCliente: TextView
    lateinit var tvProductosCantidades: TextView
    lateinit var tvSubtotal: TextView
    lateinit var tvDescuento: TextView
    lateinit var tvDelivery: TextView
    lateinit var tvIva: TextView
    lateinit var tvMetodoPago: TextView
    lateinit var tvTotal: TextView
    lateinit var btnVolver: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_boleta)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 1. Enlace de vistas con el XML
        tvNumPedido = findViewById(R.id.tvNumPedido)
        tvDatosCliente = findViewById(R.id.tvDatosCliente)
        tvProductosCantidades = findViewById(R.id.tvProductosCantidades)
        tvSubtotal = findViewById(R.id.tvSubtotalBoleta)
        tvDescuento = findViewById(R.id.tvDescuentoBoleta)
        tvDelivery = findViewById(R.id.tvDeliveryBoleta)
        tvIva = findViewById(R.id.tvIvaBoleta)
        tvMetodoPago = findViewById(R.id.tvMetodoPagoBoleta)
        tvTotal = findViewById(R.id.tvTotalBoleta)
        btnVolver = findViewById(R.id.btnVolverInicio)

        // 2. Recepción de parámetros numéricos y textuales desde MiPedidoActivity
        val bundle = intent.extras
        val producto = bundle?.getString("producto") ?: "Café Espresso"
        val cantidadStr = bundle?.getString("cantidad") ?: "1"
        val cantidad = cantidadStr.toIntOrNull() ?: 1
        val subtotal = bundle?.getString("subtotal") ?: "2200"
        val descuento = bundle?.getString("descuento") ?: "0"
        val delivery = bundle?.getString("delivery")?.toIntOrNull() ?: 0
        val iva = bundle?.getString("iva") ?: "418"
        val totalStr = bundle?.getString("total") ?: "2200"
        val total = totalStr.toDoubleOrNull() ?: 2200.0
        val metodoPago = bundle?.getString("metodoPago") ?: "Tarjeta Débito/Crédito"

        // 3. Mostrar los datos recibidos en la interfaz
        tvNumPedido.text = "N° de Pedido: #MYC-2026-01"

        if (delivery > 0) {
            tvDatosCliente.text = "Cliente: Loreto Bustos\nModo: Delivery a Domicilio (Maipú)"
        } else {
            tvDatosCliente.text = "Cliente: Loreto Bustos\nModo: Retiro presencial en tienda ($0)"
        }

        tvProductosCantidades.text = "Detalle: ${cantidad}x $producto"
        tvSubtotal.text = "Subtotal productos: $$subtotal"
        tvDescuento.text = "Descuento aplicado: -$$descuento"
        tvDelivery.text = "Servicio delivery: $$delivery"
        tvIva.text = "IVA (19% incluido): $$iva"
        tvMetodoPago.text = "Método de pago: $metodoPago"
        tvTotal.text = "Total Pagado: $$total"

        // 4. GUARDAR PERSISTENTEMENTE EN SQLITE3 (Cumple Criterios 5 y 6 de la evaluación)
        guardarPedidoEnBD(producto, cantidad, total)

        // 5. Botón Volver al inicio: limpia la pila para iniciar un nuevo pedido
        btnVolver.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
            finish()
        }
    }

    // Método que registra el movimiento del proceso en la base de datos local SQLite3
    private fun guardarPedidoEnBD(producto: String, cantidad: Int, total: Double) {
        try {
            val admin = AdminSQLiteOpenHelper(this, "administracion", null, 1)
            val bd: SQLiteDatabase = admin.writableDatabase

            // Obtener fecha y hora actual en formato legible
            val fechaActual = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())

            val registro = ContentValues().apply {
                put("producto", producto)
                put("cantidad", cantidad)
                put("total", total)
                put("fecha", fechaActual)
                put("usuario", "loreto") // O el usuario que inició sesión
            }

            val resultado = bd.insert("pedidos", null, registro)
            bd.close()

            if (resultado != -1L) {
                Toast.makeText(this, "Pedido registrado en SQLite con éxito", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Error al registrar el pedido en la BD", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Excepción al guardar: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}