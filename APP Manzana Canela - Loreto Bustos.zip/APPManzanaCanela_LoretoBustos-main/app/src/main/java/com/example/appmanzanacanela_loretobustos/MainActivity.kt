package com.example.appmanzanacanela_loretobustos

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    // Declaración de variables para los botones de la interfaz
    lateinit var btnMenu: Button
    lateinit var btnPromociones: Button
    lateinit var btnQuienesSomos: Button
    lateinit var btnContacto: Button
    lateinit var btnComenzar: Button
    lateinit var btnLogin: Button
    lateinit var btnRegistro: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 1. Enlace de vistas mediante findViewById
        btnMenu = findViewById(R.id.btnAccesoMenu)
        btnPromociones = findViewById(R.id.btnPromociones)
        btnQuienesSomos = findViewById(R.id.btnQuienesSomos)
        btnContacto = findViewById(R.id.btnContacto)
        btnComenzar = findViewById(R.id.btnComenzar)
        btnLogin = findViewById(R.id.btnIrLogin)
        btnRegistro = findViewById(R.id.btnIrRegistro)

        // 2. Navegación al Menú Principal (Activity 5)
        btnMenu.setOnClickListener {
            val intent = Intent(this, MenuPrincipalActivity::class.java)
            startActivity(intent)
        }

        btnComenzar.setOnClickListener {
            val intent = Intent(this, MenuPrincipalActivity::class.java)
            startActivity(intent)
        }

        // 3. Accesos informativos mediante Toast
        btnPromociones.setOnClickListener {
            Toast.makeText(this, "Cupón disponible: MANZANA10 (10% de descuento)", Toast.LENGTH_LONG).show()
        }

        btnQuienesSomos.setOnClickListener {
            Toast.makeText(this, "Manzana y Canela: Cafetería, tetería y matería artesanal.", Toast.LENGTH_SHORT).show()
        }

        btnContacto.setOnClickListener {
            Toast.makeText(this, "Contacto: contacto@manzanaycanela.cl | Maipú, Chile", Toast.LENGTH_SHORT).show()
        }

        // 4. Navegación a Inicio de Sesión (Activity 3)
        btnLogin.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        // 5. Navegación a Registro de Usuario (Activity 2)
        btnRegistro.setOnClickListener {
            val intent = Intent(this, RegistroUsuarioActivity::class.java)
            startActivity(intent)
        }
    }
}