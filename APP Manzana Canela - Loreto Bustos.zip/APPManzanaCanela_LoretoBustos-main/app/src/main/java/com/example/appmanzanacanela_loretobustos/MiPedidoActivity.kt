package com.example.appmanzanacanela_loretobustos

import android.content.ContentValues
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MiPedidoActivity : AppCompatActivity() {

    // Vistas de desglose del pedido
    lateinit var tvNombre: TextView
    lateinit var tvPrecioUnitario: TextView
    lateinit var etCantidad: EditText
    lateinit var tvSubtotal: TextView
    lateinit var tvEstadoEntrega: TextView
    lateinit var etCupon: EditText

    // Botones de acción
    lateinit var btnEditar: Button
    lateinit var btnEliminar: Button
    lateinit var btnRetiro: Button
    lateinit var btnDelivery: Button
    lateinit var btnConfirmar: Button
    lateinit var btnVolver: Button

    // Variables de control y cálculo
    var producto = "Café Espresso"
    var precioUnitario = 2200
    var cantidad = 1
    var subtotal = 2200
    var costoDelivery = 0
    var nombreUsuarioActivo = "admin" // Recibido por Intent o por defecto

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_mi_pedido)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 1. Enlace de vistas
        tvNombre = findViewById(R.id.tvNombreProducto)
        tvPrecioUnitario = findViewById(R.id.tvPrecioUnitario)
        etCantidad = findViewById(R.id.etCantidadPedido)
        tvSubtotal = findViewById(R.id.tvSubtotalPedido)
        tvEstadoEntrega = findViewById(R.id.tvEstadoEntrega)
        etCupon = findViewById(R.id.etCodigoCupon)

        btnEditar = findViewById(R.id.btnEditarCantidad)
        btnEliminar = findViewById(R.id.btnEliminarProducto)
        btnRetiro = findViewById(R.id.btnRetiro)
        btnDelivery = findViewById(R.id.btnDelivery)
        btnConfirmar = findViewById(R.id.btnConfirmarPedido)
        btnVolver = findViewById(R.id.btnVolverMenuDesdePedido)

        // 2. Recepción de datos desde Café, Té o Mate y el Usuario Activo
        val bundle = intent.extras
        if (bundle != null) {
            producto = bundle.getString("producto") ?: "Café Espresso"
            precioUnitario = bundle.getString("precioUnitario")?.toIntOrNull() ?: 2200
            cantidad = bundle.getString("cantidad")?.toIntOrNull() ?: 1

            // Si ya viene calculado el subtotal por Intent lo usa, si no, lo multiplica
            val subtotalIntent = bundle.getString("subtotal")?.toIntOrNull()
            subtotal = subtotalIntent ?: (precioUnitario * cantidad)

            if (bundle.containsKey("nombreUsuario")) {
                nombreUsuarioActivo = bundle.getString("nombreUsuario") ?: "admin"
            }
        }

        actualizarVistas()

        // 3. Botón EDITAR: recalcula el subtotal en memoria
        btnEditar.setOnClickListener {
            val nuevaCant = etCantidad.text.toString().toIntOrNull() ?: 0
            if (nuevaCant <= 0) {
                Toast.makeText(this, "Ingrese una cantidad válida mayor a 0", Toast.LENGTH_SHORT).show()
            } else {
                cantidad = nuevaCant
                subtotal = precioUnitario * cantidad
                actualizarVistas()
                Toast.makeText(this, "Cantidad actualizada", Toast.LENGTH_SHORT).show()
            }
        }

        // 4. Botón ELIMINAR: vacía el ítem
        btnEliminar.setOnClickListener {
            producto = "Sin producto seleccionado"
            precioUnitario = 0
            cantidad = 0
            subtotal = 0
            actualizarVistas()
            Toast.makeText(this, "Carrito vaciado", Toast.LENGTH_SHORT).show()
        }

        // 5. Botón Retiro en Tienda ($0)
        btnRetiro.setOnClickListener {
            costoDelivery = 0
            tvEstadoEntrega.text = "Entrega: Retiro en tienda ($0)"
            Toast.makeText(this, "Retiro en tienda seleccionado ($0)", Toast.LENGTH_SHORT).show()
        }

        // 6. Botón Delivery (+$2.000)
        btnDelivery.setOnClickListener {
            costoDelivery = 2000
            tvEstadoEntrega.text = "Entrega: Delivery (+$2.000)"
            Toast.makeText(this, "Delivery seleccionado (+$2.000)", Toast.LENGTH_SHORT).show()
        }

        // 7. Botón Confirmar: GUARDA EN SQLITE (Persistencia) y deriva a Boleta
        btnConfirmar.setOnClickListener {
            if (cantidad <= 0 || subtotal <= 0) {
                Toast.makeText(this, "Debe tener al menos un producto en el carrito", Toast.LENGTH_SHORT).show()
            } else {
                // Cálculo de cupones, descuento e IVA
                val cupon = etCupon.text.toString().trim().uppercase()
                var descuento = 0.0
                if (cupon == "MANZANA10") {
                    descuento = subtotal * 0.10 // 10% de descuento
                }

                val subtotalConDescuento = subtotal - descuento
                val iva = subtotalConDescuento * 0.19 // 19% IVA incluido en el cálculo
                val totalFinal = subtotalConDescuento + costoDelivery

                // Obtener fecha y hora actual formateada
                val fechaActual = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())

                // GUARDAR EN BASE DE DATOS SQLite ("administracion", tabla pedidos)
                val admin = AdminSQLiteOpenHelper(this, "administracion", null, 1)
                val db = admin.writableDatabase
                val registro = ContentValues().apply {
                    put("producto", producto)
                    put("cantidad", cantidad)
                    put("total", totalFinal)
                    put("fecha", fechaActual)
                    put("usuario", nombreUsuarioActivo)
                }

                val resultado = db.insert("pedidos", null, registro)
                db.close()

                if (resultado != -1L) {
                    Toast.makeText(this, "¡Pedido registrado con éxito en SQLite!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Error al registrar el pedido en la base de datos", Toast.LENGTH_SHORT).show()
                }

                // Derivar a la Boleta pasando todos los parámetros calculados
                val intent = Intent(this, BoletaActivity::class.java).apply {
                    putExtra("producto", producto)
                    putExtra("cantidad", cantidad.toString())
                    putExtra("precioUnitario", precioUnitario.toString())
                    putExtra("subtotal", subtotal.toString())
                    putExtra("descuento", descuento.toInt().toString())
                    putExtra("delivery", costoDelivery.toString())
                    putExtra("iva", iva.toInt().toString())
                    putExtra("total", totalFinal.toInt().toString())
                    putExtra("metodoPago", "Tarjeta Débito/Crédito")
                }
                startActivity(intent)
            }
        }

        // 8. Botón Seguir Comprando: vuelve al Menú
        btnVolver.setOnClickListener {
            finish()
        }
    }

    private fun actualizarVistas() {
        tvNombre.text = "Producto: $producto"
        tvPrecioUnitario.text = "Precio unitario: $$precioUnitario"
        etCantidad.setText(cantidad.toString())
        tvSubtotal.text = "Subtotal del pedido: $$subtotal"
    }
}