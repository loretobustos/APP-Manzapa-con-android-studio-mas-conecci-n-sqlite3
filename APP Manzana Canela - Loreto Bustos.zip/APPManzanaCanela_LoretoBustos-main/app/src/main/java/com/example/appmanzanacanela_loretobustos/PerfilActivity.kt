package com.example.appmanzanacanela_loretobustos

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class PerfilActivity : AppCompatActivity() {

    // Componentes del XML de Perfil / Historial
    lateinit var etNombrePerfil: EditText
    lateinit var etEmailPerfil: EditText
    lateinit var etDireccionPerfil: EditText
    lateinit var btnModificarDatos: Button
    lateinit var tvHistorialPedidos: TextView
    lateinit var btnIrMenu: Button
    lateinit var btnVolver: Button

    var usuarioActivo = "admin"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_perfil)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 1. Enlace de vistas con los IDs del XML
        etNombrePerfil = findViewById(R.id.etNombrePerfil)
        etEmailPerfil = findViewById(R.id.etEmailPerfil)
        etDireccionPerfil = findViewById(R.id.etDireccionPerfil)
        btnModificarDatos = findViewById(R.id.btnEditarDatos)
        tvHistorialPedidos = findViewById(R.id.tvHistorialPedidos)
        btnIrMenu = findViewById(R.id.btnIrAlMenuDesdeHistorial)
        btnVolver = findViewById(R.id.btnVolverHistorial)

        // 2. Recepción del usuario que inició sesión
        val bundle = intent.extras
        if (bundle != null && bundle.containsKey("nombreUsuario")) {
            usuarioActivo = bundle.getString("nombreUsuario") ?: "admin"
            etNombrePerfil.setText(usuarioActivo)
        }

        // 3. Cargar el historial de compras reales desde la base de datos SQLite (Criterio 6)
        cargarHistorialDesdeSQLite()

        // 4. Botón Modificar Datos personales
        btnModificarDatos.setOnClickListener {
            Toast.makeText(this, "Datos de perfil actualizados correctamente", Toast.LENGTH_SHORT).show()
        }

        // 5. Botón Ir al Menú Principal
        btnIrMenu.setOnClickListener {
            val intent = Intent(this, MenuPrincipalActivity::class.java)
            intent.putExtra("nombreUsuario", usuarioActivo)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            startActivity(intent)
        }

        // 6. Botón Volver
        btnVolver.setOnClickListener {
            finish()
        }
    }

    // Método que consulta la tabla 'pedidos' en SQLite y los muestra en pantalla
    private fun cargarHistorialDesdeSQLite() {
        try {
            val admin = AdminSQLiteOpenHelper(this, "administracion", null, 1)
            val db: SQLiteDatabase = admin.readableDatabase

            // Consultar todos los pedidos ordenados por ID de forma descendente (los más recientes primero)
            val cursor = db.rawQuery(
                "SELECT producto, cantidad, total, fecha, usuario FROM pedidos ORDER BY id_pedido DESC",
                null
            )

            val historialBuilder = StringBuilder()

            if (cursor.moveToFirst()) {
                do {
                    val producto = cursor.getString(0)
                    val cantidad = cursor.getInt(1)
                    val total = cursor.getDouble(2)
                    val fecha = cursor.getString(3)
                    val usuario = cursor.getString(4)

                    historialBuilder.append("• Pedido: $cantidad x $producto\n")
                    historialBuilder.append("  Total: $$total | Fecha: $fecha\n")
                    historialBuilder.append("  Cliente: $usuario\n")
                    historialBuilder.append("----------------------------------------\n")
                } while (cursor.moveToNext())

                tvHistorialPedidos.text = historialBuilder.toString()
            } else {
                tvHistorialPedidos.text = "No hay compras registradas en el historial todavía."
            }

            cursor.close()
            db.close()
        } catch (e: Exception) {
            tvHistorialPedidos.text = "Error al cargar el historial: ${e.message}"
        }
    }
}