package com.example.appmanzanacanela_loretobustos

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

// Usuario de prueba por defecto en SQLite: admin / 123456
class LoginActivity : AppCompatActivity() {

    lateinit var etNombre: EditText
    lateinit var etClave: EditText
    lateinit var btnIngresar: Button
    lateinit var btnHistorial: Button
    lateinit var btnRegistro: Button
    lateinit var btnVolver: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 1. Enlace de vistas con findViewById
        etNombre = findViewById(R.id.etNombreLogin)
        etClave = findViewById(R.id.etClaveLogin)
        btnIngresar = findViewById(R.id.btnIngresar)
        btnHistorial = findViewById(R.id.btnVerHistorial)
        btnRegistro = findViewById(R.id.btnIrRegistroLogin)
        btnVolver = findViewById(R.id.btnVolverLogin)

        // 2. Botón Iniciar Sesión: Valida en SQLite y abre el Menú Principal
        btnIngresar.setOnClickListener {
            val nombre = etNombre.text.toString().trim()
            val clave = etClave.text.toString().trim()

            if (validarCredencialesSQLite(nombre, clave)) {
                Toast.makeText(this, "¡Bienvenida/o, $nombre!", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, MenuPrincipalActivity::class.java)
                intent.putExtra("nombreUsuario", nombre)
                startActivity(intent)
                finish()
            }
        }

        // 3. Botón Ver Historial: También exige login válido (Restricción de acceso)
        btnHistorial.setOnClickListener {
            val nombre = etNombre.text.toString().trim()
            val clave = etClave.text.toString().trim()

            if (validarCredencialesSQLite(nombre, clave)) {
                val intent = Intent(this, PerfilActivity::class.java)
                intent.putExtra("nombreUsuario", nombre)
                startActivity(intent)
            }
        }

        // 4. Botón Registrar Nuevo Usuario
        btnRegistro.setOnClickListener {
            val intent = Intent(this, RegistroUsuarioActivity::class.java)
            startActivity(intent)
        }

        // 5. Botón Volver
        btnVolver.setOnClickListener {
            finish()
        }
    }

    // Función que valida campos obligatorios y consulta la tabla usuarios en SQLite3
    private fun validarCredencialesSQLite(nombre: String, clave: String): Boolean {
        if (nombre.isEmpty() || clave.isEmpty()) {
            Toast.makeText(this, "Debe ingresar su usuario y clave", Toast.LENGTH_SHORT).show()
            return false
        }
        if (clave.length != 6) {
            Toast.makeText(this, "La clave debe tener 6 dígitos numéricos", Toast.LENGTH_SHORT).show()
            return false
        }

        // Se usa "administracion" para compartir la misma BD en toda la app
        val admin = AdminSQLiteOpenHelper(this, "administracion", null, 1)
        val db = admin.readableDatabase
        val fila = db.rawQuery(
            "SELECT nombre_usuario FROM usuarios WHERE nombre_usuario = ? AND contrasena = ?",
            arrayOf(nombre, clave)
        )

        val esValido = fila.moveToFirst()
        fila.close()
        db.close()

        if (!esValido) {
            Toast.makeText(this, "Acceso denegado: usuario o clave incorrectos", Toast.LENGTH_SHORT).show()
        }
        return esValido
    }
}