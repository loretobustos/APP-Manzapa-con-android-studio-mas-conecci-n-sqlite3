package com.example.appmanzanacanela_loretobustos

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class AdminSQLiteOpenHelper(context: Context, name: String, factory: SQLiteDatabase.CursorFactory?, version: Int) :
    SQLiteOpenHelper(context, name, factory, version) {

    override fun onCreate(db: SQLiteDatabase) {
        // 1. Tabla Usuarios
        db.execSQL("CREATE TABLE usuarios (id_usuario INTEGER PRIMARY KEY AUTOINCREMENT, nombre_usuario TEXT, contrasena TEXT)")

        // 2. Tabla Productos (Carga real para Café, Té, Mate, etc.)
        db.execSQL("CREATE TABLE productos (id_producto INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT, precio REAL, disponibilidad INTEGER)")

        // 3. Tabla Pedidos (Historial y persistencia del proceso)
        db.execSQL("CREATE TABLE pedidos (id_pedido INTEGER PRIMARY KEY AUTOINCREMENT, producto TEXT, cantidad INTEGER, total REAL, fecha TEXT, usuario TEXT)")

        // Insertar datos de prueba iniciales (Usuarios)
        db.execSQL("INSERT INTO usuarios(nombre_usuario, contrasena) VALUES ('admin', '123456')")
        db.execSQL("INSERT INTO usuarios(nombre_usuario, contrasena) VALUES ('loreto', '123456')")

        // Insertar productos de prueba: CAFÉS (Alineados con CafeActivity)
        db.execSQL("INSERT INTO productos(nombre, precio, disponibilidad) VALUES ('Café Espresso', 2200.0, 20)")
        db.execSQL("INSERT INTO productos(nombre, precio, disponibilidad) VALUES ('Cappuccino Canela', 3200.0, 15)")
        db.execSQL("INSERT INTO productos(nombre, precio, disponibilidad) VALUES ('Latte Manzana', 3500.0, 12)")

        // Insertar productos de prueba: TÉS (Alineados con TeActivity)
        db.execSQL("INSERT INTO productos(nombre, precio, disponibilidad) VALUES ('Té Chai Especiado', 2800.0, 18)")
        db.execSQL("INSERT INTO productos(nombre, precio, disponibilidad) VALUES ('Té Verde Jazmín', 2500.0, 15)")
        db.execSQL("INSERT INTO productos(nombre, precio, disponibilidad) VALUES ('Infusión Manzana', 2600.0, 10)")

        // Insertar productos de prueba: MATES (Alineados con MateActivity)
        db.execSQL("INSERT INTO productos(nombre, precio, disponibilidad) VALUES ('Mate Tradicional', 2400.0, 20)")
        db.execSQL("INSERT INTO productos(nombre, precio, disponibilidad) VALUES ('Mate Canela & Cítricos', 2900.0, 14)")
        db.execSQL("INSERT INTO productos(nombre, precio, disponibilidad) VALUES ('Mate Hierbas', 2700.0, 12)")

        // Pedido de prueba inicial para verificar en App Inspection
        db.execSQL("INSERT INTO pedidos (producto, cantidad, total, fecha, usuario) VALUES ('Café Espresso', 2, 4400.0, '17/11/2026 10:30', 'admin')")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS usuarios")
        db.execSQL("DROP TABLE IF EXISTS productos")
        db.execSQL("DROP TABLE IF EXISTS pedidos")
        onCreate(db)
    }
}