package com.example.appmanzanacanela_loretobustos

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class TeActivity : AppCompatActivity() {

    // 1. Declaración de variables para los componentes de la interfaz
    lateinit var btnChai: Button
    lateinit var btnVerde: Button
    lateinit var btnFrutal: Button
    lateinit var btnIrPedido: Button
    lateinit var btnVolver: Button

    lateinit var etCantChai: EditText
    lateinit var etCantVerde: EditText
    lateinit var etCantFrutal: EditText

    // TextViews para mostrar los precios cargados desde SQLite
    lateinit var tvPrecioChai: TextView
    lateinit var tvPrecioVerde: TextView
    lateinit var tvPrecioFrutal: TextView

    // Variables para almacenar los precios obtenidos de la BD
    var precioChai = 0
    var precioVerde = 0
    var precioFrutal = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_te)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 2. Enlace de vistas con el XML usando los IDs exactos
        btnChai = findViewById(R.id.btnPedirChai)
        btnVerde = findViewById(R.id.btnPedirVerde)
        btnFrutal = findViewById(R.id.btnPedirFrutal)
        btnIrPedido = findViewById(R.id.btnIrPedidoTe)
        btnVolver = findViewById(R.id.btnVolverMenuDesdeTe)

        etCantChai = findViewById(R.id.etCantChai)
        etCantVerde = findViewById(R.id.etCantVerde)
        etCantFrutal = findViewById(R.id.etCantFrutal)

        tvPrecioChai = findViewById(R.id.tvPrecioChai)
        tvPrecioVerde = findViewById(R.id.tvPrecioVerde)
        tvPrecioFrutal = findViewById(R.id.tvPrecioFrutal)

        // 3. Cargar precios reales desde SQLite3 (Cumple Criterio 3 de la evaluación)
        cargarPreciosDesdeBD()

        // 4. Eventos al presionar Pedir en cada variedad
        btnChai.setOnClickListener {
            procesarPedido("Té Chai Especiado", etCantChai.text.toString(), precioChai)
        }

        btnVerde.setOnClickListener {
            procesarPedido("Té Verde Jazmín", etCantVerde.text.toString(), precioVerde)
        }

        btnFrutal.setOnClickListener {
            procesarPedido("Infusión Manzana", etCantFrutal.text.toString(), precioFrutal)
        }

        // 5. Ir directo al carrito / pedido
        btnIrPedido.setOnClickListener {
            val intent = Intent(this, MiPedidoActivity::class.java)
            startActivity(intent)
        }

        // 6. Volver a la pantalla del menú
        btnVolver.setOnClickListener {
            finish()
        }
    }

    // Método para leer los precios desde la base de datos SQLite
    private fun cargarPreciosDesdeBD() {
        val admin = AdminSQLiteOpenHelper(this, "administracion", null, 1)
        val bd: SQLiteDatabase = admin.readableDatabase

        // Consultamos los productos relacionados con el té en la tabla productos
        val filaChai = bd.rawQuery("SELECT precio FROM productos WHERE nombre='Té Chai Especiado'", null)
        if (filaChai.moveToFirst()) {
            precioChai = filaChai.getInt(0)
            tvPrecioChai.text = "$$precioChai"
        } else {
            tvPrecioChai.text = "No disponible"
        }
        filaChai.close()

        val filaVerde = bd.rawQuery("SELECT precio FROM productos WHERE nombre='Té Verde Jazmín'", null)
        if (filaVerde.moveToFirst()) {
            precioVerde = filaVerde.getInt(0)
            tvPrecioVerde.text = "$$precioVerde"
        } else {
            tvPrecioVerde.text = "No disponible"
        }
        filaVerde.close()

        val filaFrutal = bd.rawQuery("SELECT precio FROM productos WHERE nombre='Infusión Manzana'", null)
        if (filaFrutal.moveToFirst()) {
            precioFrutal = filaFrutal.getInt(0)
            tvPrecioFrutal.text = "$$precioFrutal"
        } else {
            tvPrecioFrutal.text = "No disponible"
        }
        filaFrutal.close()

        bd.close()
    }

    // 7. Procesamiento numérico y paso de parámetros
    private fun procesarPedido(producto: String, textoCantidad: String, precioUnitario: Int) {
        val cantidad = textoCantidad.toIntOrNull() ?: 1 // Si está vacío toma por defecto 1

        if (cantidad <= 0) {
            Toast.makeText(this, "Ingrese una cantidad válida mayor a 0", Toast.LENGTH_SHORT).show()
        } else if (precioUnitario == 0) {
            Toast.makeText(this, "Error: No se pudo cargar el precio del producto", Toast.LENGTH_SHORT).show()
        } else {
            val subtotal = precioUnitario * cantidad

            val intent = Intent(this, MiPedidoActivity::class.java)
            intent.putExtra("producto", producto)
            intent.putExtra("cantidad", cantidad.toString())
            intent.putExtra("precioUnitario", precioUnitario.toString())
            intent.putExtra("subtotal", subtotal.toString())
            startActivity(intent)

            Toast.makeText(this, "$producto agregado al pedido", Toast.LENGTH_SHORT).show()
        }
    }
}