package com.example.appmanzanacanela_loretobustos

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MateActivity : AppCompatActivity() {

    // Declaración de botones
    lateinit var btnTradicional: Button
    lateinit var btnCanela: Button
    lateinit var btnHierbas: Button
    lateinit var btnIrPedido: Button
    lateinit var btnVolver: Button

    // Declaración de entradas de cantidad
    lateinit var etCantTradicional: EditText
    lateinit var etCantCanela: EditText
    lateinit var etCantHierbas: EditText

    // TextViews para mostrar los precios cargados desde SQLite
    lateinit var tvPrecioTradicional: TextView
    lateinit var tvPrecioCanela: TextView
    lateinit var tvPrecioHierbas: TextView

    // Precios que se llenarán dinámicamente desde la BD
    var precioTradicional = 0
    var precioCanela = 0
    var precioHierbas = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_mate)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // 1. Enlace de vistas mediante findViewById
        btnTradicional = findViewById(R.id.btnPedirTradicional)
        btnCanela = findViewById(R.id.btnPedirCanela)
        btnHierbas = findViewById(R.id.btnPedirHierbas)
        btnIrPedido = findViewById(R.id.btnIrPedidoMate)
        btnVolver = findViewById(R.id.btnVolverMenuDesdeMate)

        etCantTradicional = findViewById(R.id.etCantTradicional)
        etCantCanela = findViewById(R.id.etCantCanela)
        etCantHierbas = findViewById(R.id.etCantHierbas)

        tvPrecioTradicional = findViewById(R.id.tvPrecioTradicional)
        tvPrecioCanela = findViewById(R.id.tvPrecioCanela)
        tvPrecioHierbas = findViewById(R.id.tvPrecioHierbas)

        // Cargar precios reales desde la base de datos SQLite (Criterio 3)
        cargarPreciosDesdeBD()

        // 2. Eventos de cada botón de pedir
        btnTradicional.setOnClickListener {
            procesarPedido("Mate Tradicional", etCantTradicional.text.toString(), precioTradicional)
        }

        btnCanela.setOnClickListener {
            procesarPedido("Mate Canela & Cítricos", etCantCanela.text.toString(), precioCanela)
        }

        btnHierbas.setOnClickListener {
            procesarPedido("Mate Hierbas", etCantHierbas.text.toString(), precioHierbas)
        }

        // 3. Botón para ir al pedido / carrito
        btnIrPedido.setOnClickListener {
            val intent = Intent(this, MiPedidoActivity::class.java)
            startActivity(intent)
        }

        // 4. Botón Volver al menú
        btnVolver.setOnClickListener {
            finish()
        }
    }

    // Método para consultar precios reales en la base de datos SQLite3
    private fun cargarPreciosDesdeBD() {
        val admin = AdminSQLiteOpenHelper(this, "administracion", null, 1)
        val bd: SQLiteDatabase = admin.readableDatabase

        // Consulta para Mate Tradicional
        val filaTradicional = bd.rawQuery("select precio from productos where nombre='Mate Tradicional'", null)
        if (filaTradicional.moveToFirst()) {
            precioTradicional = filaTradicional.getInt(0)
            tvPrecioTradicional.text = "$$precioTradicional"
        } else {
            tvPrecioTradicional.text = "No disponible"
        }
        filaTradicional.close()

        // Consulta para Mate Canela & Cítricos
        val filaCanela = bd.rawQuery("select precio from productos where nombre='Mate Canela & Cítricos'", null)
        if (filaCanela.moveToFirst()) {
            precioCanela = filaCanela.getInt(0)
            tvPrecioCanela.text = "$$precioCanela"
        } else {
            tvPrecioCanela.text = "No disponible"
        }
        filaCanela.close()

        // Consulta para Mate Hierbas
        val filaHierbas = bd.rawQuery("select precio from productos where nombre='Mate Hierbas'", null)
        if (filaHierbas.moveToFirst()) {
            precioHierbas = filaHierbas.getInt(0)
            tvPrecioHierbas.text = "$$precioHierbas"
        } else {
            tvPrecioHierbas.text = "No disponible"
        }
        filaHierbas.close()

        bd.close()
    }

    // Procesamiento numérico y paso de parámetros
    private fun procesarPedido(producto: String, textoCantidad: String, precioUnitario: Int) {
        val cantidad = textoCantidad.toIntOrNull() ?: 1

        if (cantidad <= 0) {
            Toast.makeText(this, "Ingrese una cantidad válida mayor a 0", Toast.LENGTH_SHORT).show()
        } else if (precioUnitario == 0) {
            Toast.makeText(this, "Error: No se pudo cargar el precio del producto", Toast.LENGTH_SHORT).show()
        } else {
            // Operación aritmética en Kotlin: Subtotal = Precio * Cantidad
            val subtotal = precioUnitario * cantidad

            val intent = Intent(this, MiPedidoActivity::class.java)
            intent.putExtra("producto", producto)
            intent.putExtra("cantidad", cantidad.toString())
            intent.putExtra("precioUnitario", precioUnitario.toString())
            intent.putExtra("subtotal", subtotal.toString())
            startActivity(intent)

            Toast.makeText(this, "$producto agregado al pedido", Toast.LENGTH_SHORT).show()
        }
    }
}